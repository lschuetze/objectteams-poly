package java.lang;

public class Exception extends Throwable {
}
