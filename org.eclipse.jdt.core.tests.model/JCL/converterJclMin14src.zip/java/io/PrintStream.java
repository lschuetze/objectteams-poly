package java.io;

public class PrintStream {
    public void println(String x) {
    }
    public void println(int x) {
    }
}
