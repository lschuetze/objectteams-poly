package java.lang;

public class Error extends Throwable {

	public Error(java.lang.String s) {
		// TODO Auto-generated constructor stub
	}

	public Error(java.lang.String s, java.lang.Throwable cause) {
		// TODO Auto-generated constructor stub
	}

	public Error() {
		// TODO Auto-generated constructor stub
	}
}
