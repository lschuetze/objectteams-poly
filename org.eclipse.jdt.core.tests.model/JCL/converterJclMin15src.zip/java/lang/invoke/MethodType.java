package java.lang.invoke;


public final class MethodType {
	public static MethodType methodType(Class<?> rtype, Class<?> ptype0,
			Class<?>... ptypes) {
		return null;
	}

	public static MethodType methodType(Class<?> rtype) {
		return null;
	}

	public static MethodType genericMethodType(int objectArgCount) {
		return null;
	}
}
