package java.lang;

public
class NoSuchFieldError extends IncompatibleClassChangeError {

    public NoSuchFieldError() {
        super();
    }

    public NoSuchFieldError(String s) {
        super(s);
    }
}
