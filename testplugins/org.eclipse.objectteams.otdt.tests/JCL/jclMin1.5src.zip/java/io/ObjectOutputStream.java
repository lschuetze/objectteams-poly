package java.io;

public class ObjectOutputStream {
	public void writeBoolean(boolean flag) throws IOException {}
}
