package java.util;

public class ArrayList<E> implements Collection<E> {
	
	public ArrayList(int i) {}
	public ArrayList() {}
	
	public void addAll(Collection<? extends E> other) { }
	public void add(Object elem) {}

	public E[] toArray() { return null; }
	public <T> T[] toArray(T[] other) { return null; }

	public int size() { return 0; }

	public Iterator<E> iterator() { return null; }

}
