package java.lang;

public class Integer {
    public int intValue() {
        return 0;
    }
    public static Integer valueOf(int i) { return null; }
}
