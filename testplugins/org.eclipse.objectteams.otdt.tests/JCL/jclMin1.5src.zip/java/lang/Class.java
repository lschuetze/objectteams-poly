package java.lang;

public class Class<T> {
	public String getName() { return null; }
	public boolean isInstance(Object o) { return false; }
	public boolean isAssignableFrom (Class<?> other) { return false; }
}
