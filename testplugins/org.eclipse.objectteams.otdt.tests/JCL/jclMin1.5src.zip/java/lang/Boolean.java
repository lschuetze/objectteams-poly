package java.lang;

public class Boolean {
	public static Boolean TRUE = new Boolean();
}
