package java.lang;

public class IllegalThreadStateException extends IllegalArgumentException {

	public IllegalThreadStateException(java.lang.String msg) {
		super(msg);
	}

}
