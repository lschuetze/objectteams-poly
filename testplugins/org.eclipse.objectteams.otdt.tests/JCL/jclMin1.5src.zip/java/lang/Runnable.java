package java.lang;

public interface Runnable {

}
