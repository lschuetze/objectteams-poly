package java.io;

public class ObjectInputStream {
	public boolean readBoolean() throws IOException  { return false; }
}
