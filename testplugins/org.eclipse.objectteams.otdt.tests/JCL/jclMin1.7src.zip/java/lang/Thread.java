package java.lang;

public class Thread implements Runnable {

	public void run() { }

	public static Thread currentThread() { return null; }
	public boolean isAlive() { return true; }
}
