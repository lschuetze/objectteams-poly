package java.lang;

public class ThreadLocal<T> {
	public void set(T t) {}
	public T get() { return null; }
}
