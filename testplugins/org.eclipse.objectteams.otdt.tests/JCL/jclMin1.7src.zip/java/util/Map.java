package java.util;

public interface Map<K,V> {
	public interface Entry<K,V> {
		
	}
}
