package java.util;

public interface List<E> extends Collection<E> {
}
