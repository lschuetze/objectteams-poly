package java.lang;

public class ThreadLocal<T> {

}
