package java.lang;

public class String implements CharSequence {
	public int length() { return 0; }
}
