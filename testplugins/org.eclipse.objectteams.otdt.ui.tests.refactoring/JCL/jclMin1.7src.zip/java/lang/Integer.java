package java.lang;

public class Integer {
	public int intValue() { return 0; }
}
