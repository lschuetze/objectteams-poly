package java.lang.reflect;


public class Array {
    public static Object newInstance(Class<?> componentType, int length) { return null; }

}
