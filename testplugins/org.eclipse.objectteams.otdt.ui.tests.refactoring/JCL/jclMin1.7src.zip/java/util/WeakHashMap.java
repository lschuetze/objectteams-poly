package java.util;

public class WeakHashMap<K, V> implements Map<K, V> {

}
