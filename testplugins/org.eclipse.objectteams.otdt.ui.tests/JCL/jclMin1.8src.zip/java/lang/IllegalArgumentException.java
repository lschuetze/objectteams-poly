package java.lang;

public class IllegalArgumentException extends RuntimeException {

	public IllegalArgumentException(String msg) {
		super();
	}

}
