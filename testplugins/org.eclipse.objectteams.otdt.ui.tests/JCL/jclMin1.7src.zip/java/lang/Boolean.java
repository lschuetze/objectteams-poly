package java.lang;

public class Boolean {

}
