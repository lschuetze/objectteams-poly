package java.util;

public abstract class AbstractMap<K, V> implements Map<K, V> {

}
