package java.util;

public interface Map<K, V> {
	public class Entry<K,V> {}
}
