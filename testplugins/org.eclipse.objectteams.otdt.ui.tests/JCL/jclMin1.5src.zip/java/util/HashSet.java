package java.util;

public class HashSet<E> {

}
