package java.util;

public class WeakHashMap<K,V> extends AbstractMap<K,V>  {

}
