package java.lang;

public class ThreadLocal<T> {
	protected synchronized T initialValue() { return null; }
}
