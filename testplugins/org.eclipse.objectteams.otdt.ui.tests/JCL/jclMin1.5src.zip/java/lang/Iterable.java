package java.lang;

import java.util.Iterator;

public interface Iterable<E> {
	Iterator<E> iterator();
}
