package java.lang;

public class Thread implements Runnable {

	public void run() { }

}
