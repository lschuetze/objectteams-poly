package java.lang;

public class Boolean {
	public static Boolean TRUE = new Boolean();
	public boolean booleanValue() { return false; }
	public static Boolean valueOf(boolean bool) { return TRUE; }
}
