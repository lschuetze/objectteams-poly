package java.lang;

public class Integer {

}
